package TransmissaoDadosMinisterio;

public class TransmissaoDados {
	public static void geraDados() {
		
	}
}
