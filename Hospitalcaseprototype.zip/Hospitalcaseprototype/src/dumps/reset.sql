drop database hospital;
create database hospital;
use hospital;