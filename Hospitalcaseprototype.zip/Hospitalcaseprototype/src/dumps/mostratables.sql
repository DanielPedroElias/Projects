-- Selecionando todas as linhas da tabela Endereco
SELECT * FROM Endereco;

-- Selecionando todas as linhas da tabela Pessoa
SELECT * FROM Pessoa;

-- Selecionando todas as linhas da tabela Plano
SELECT * FROM Plano;

-- Selecionando todas as linhas da tabela Paciente
SELECT * FROM Paciente;

-- Selecionando todas as linhas da tabela Medico
SELECT * FROM Medico;

-- Selecionando todas as linhas da tabela Sala
SELECT * FROM Sala;

-- Selecionando todas as linhas da tabela Procedimento
SELECT * FROM Procedimento;

-- Selecionando todas as linhas da tabela Consulta
SELECT * FROM Consulta;

-- Selecionando todas as linhas da tabela Especialidade
SELECT * FROM Especialidade;

-- Selecionando todas as linhas da tabela Medico_Especialidade
SELECT * FROM Medico_Especialidade;

-- Selecionando todas as linhas da tabela ITransmissaoDadoMinisterio
SELECT * FROM ITransmissaoDadoMinisterio;

-- Selecionando todas as linhas da tabela Neurocirurgia
SELECT * FROM Neurocirurgia;

-- Selecionando todas as linhas da tabela Faringoplastia
SELECT * FROM Faringoplastia;
